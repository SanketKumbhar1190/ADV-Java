package day3.com.shopping.DAO;

  import java.sql.Connection;
  import java.sql.DriverManager;
  import java.sql.PreparedStatement;
  import java.sql.ResultSet;
  import java.util.ArrayList;
  import java.util.List;

  public class ShoppingDAOImpl implements ShoppingDAO {
      private static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/advjavab2";
      private static final String DB_USER = "root";
      private static final String DB_PASSWORD = "root";

      static {
          try {
              Class.forName("com.mysql.cj.jdbc.Driver");
          } catch (ClassNotFoundException e) {
              throw new RuntimeException("Failed to load MySQL JDBC driver", e);
          }
      }

      @Override
      public boolean authenticateUser(String username, String password) throws Exception {
          String sql = "SELECT * FROM assign1 WHERE username = ? AND password = ?";
          try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
               PreparedStatement stmt = conn.prepareStatement(sql)) {
              stmt.setString(1, username);
              stmt.setString(2, password);
              try (ResultSet rs = stmt.executeQuery()) {
                  return rs.next();
              }
          }
      }

      @Override
      public List<Category> getAllCategories() throws Exception {
          List<Category> categories = new ArrayList<>();
          String sql = "SELECT * FROM category";
          try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
               PreparedStatement stmt = conn.prepareStatement(sql);
               ResultSet rs = stmt.executeQuery()) {
              while (rs.next()) {
                  Category category = new Category(
                      rs.getInt("categoryId"),
                      rs.getString("categoryName"),
                      rs.getString("categoryDescription"),
                      rs.getString("categoryImageUrl")
                  );
                  categories.add(category);
              }
          }
          return categories;
      }

      @Override
      public List<Product> getProductsByCategoryId(int categoryId) throws Exception {
          List<Product> products = new ArrayList<>();
          String sql = "SELECT * FROM products WHERE categoryID = ?";
          try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
               PreparedStatement stmt = conn.prepareStatement(sql)) {
              stmt.setInt(1, categoryId);
              try (ResultSet rs = stmt.executeQuery()) {
                  while (rs.next()) {
                      Product product = new Product(
                          rs.getInt("productID"),
                          rs.getString("productNAME"),
                          rs.getString("productDESCRIPTION"),
                          rs.getDouble("productPRICE"),
                          rs.getString("productIMAGEURL")
                      );
                      products.add(product);
                  }
              }
          }
          return products;
      }
  }