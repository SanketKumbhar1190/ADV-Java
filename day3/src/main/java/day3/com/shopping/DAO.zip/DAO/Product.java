package day3.com.shopping.DAO;

public class Product {
    private int productId;
    private String productName;
    private String productDescription;
    private double productPrice;
    private String productImageUrl;

    public Product(int productId, String productName, String productDescription, double productPrice, String productImageUrl) {
        this.productId = productId;
        this.productName = productName;
        this.productDescription = productDescription;
        this.productPrice = productPrice;
        this.productImageUrl = productImageUrl;
    }

    public int getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public String getProductImageUrl() {
        return productImageUrl;
    }
}