package day3.com.shopping.DAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/CategoryServlet")
public class CategoryServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if (session != null && session.getAttribute("uname") != null) {
            String name = (String) session.getAttribute("uname");

            out.println("<h2>Welcome, " + name + "!</h2>");
            out.println("<h3>Product Categories</h3>");
            out.println("<ul>");
            out.println("<li>Electronics</li>");
            out.println("<li>Clothing</li>");
            out.println("<li>Books</li>");
            out.println("<li>Groceries</li>");
            out.println("<li>Home Appliances</li>");
            out.println("</ul>");
        } else {
            out.println("<h3>Please login first.</h3>");
            response.sendRedirect("Login.html");
        }
    }
}
