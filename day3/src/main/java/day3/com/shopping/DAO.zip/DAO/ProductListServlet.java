package day3.com.shopping.DAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet("/products")
public class ProductListServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private ShoppingDAO shoppingDAO;

    @Override
    public void init() throws ServletException {
        shoppingDAO = new ShoppingDAOImpl();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        out.println("<html><body><table border='1'>");
        out.println("<tr><th>ID</th><th>Name</th><th>Description</th><th>Price</th><th>Image</th></tr>");

        String tmpID = request.getParameter("categoryId");
        if (tmpID == null || tmpID.trim().isEmpty()) {
            out.println("<tr><td colspan='5'>Error: Category ID is missing.</td></tr>");
        } else {
            try {
                int categoryID = Integer.parseInt(tmpID);
                List<Product> products = shoppingDAO.getProductsByCategoryId(categoryID);
                for (Product product : products) {
                    out.println("<tr>");
                    out.println("<td>" + product.getProductId() + "</td>");
                    out.println("<td>" + product.getProductName() + "</td>");
                    out.println("<td>" + product.getProductDescription() + "</td>");
                    out.println("<td>" + product.getProductPrice() + "</td>");
                    out.println("<td><img src='" + product.getProductImageUrl() + "' height='60px' width='60px' /></td>");
                    out.println("</tr>");
                }
            } catch (NumberFormatException e) {
                out.println("<tr><td colspan='5'>Error: Invalid Category ID.</td></tr>");
            } catch (Exception e) {
                out.println("<tr><td colspan='5'>Error fetching products: " + e.getMessage() + "</td></tr>");
            }
        }

        out.println("</table></body></html>");
    }
}