package day3.com.shopping.DAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/Authenticate")
public class Authenticate extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String user = request.getParameter("username");
        String pass = request.getParameter("password");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if ("sanket".equals(user) && "123".equals(pass)) {
            HttpSession session = request.getSession();
            session.setAttribute("uname", user);
            response.sendRedirect("CategoryServlet");
        } else {
            out.println("<h3 style='color:red;'>Invalid Credentials</h3>");
            request.getRequestDispatcher("Login.html").include(request, response);
        }
    }
}
