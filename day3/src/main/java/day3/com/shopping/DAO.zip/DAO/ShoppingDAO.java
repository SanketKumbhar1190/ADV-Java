package day3.com.shopping.DAO;

  import java.util.List;

  public interface ShoppingDAO {
      boolean authenticateUser(String username, String password) throws Exception;
      List<Category> getAllCategories() throws Exception;
      List<Product> getProductsByCategoryId(int categoryId) throws Exception;
  }