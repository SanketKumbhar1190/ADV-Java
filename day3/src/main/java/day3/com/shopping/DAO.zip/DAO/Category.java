package day3.com.shopping.DAO;

  public class Category {
      private int categoryId;
      private String categoryName;
      private String categoryDescription;
      private String categoryImageUrl;

      public Category(int categoryId, String categoryName, String categoryDescription, String categoryImageUrl) {
          this.categoryId = categoryId;
          this.categoryName = categoryName;
          this.categoryDescription = categoryDescription;
          this.categoryImageUrl = categoryImageUrl;
      }

      public int getCategoryId() {
          return categoryId;
      }

      public String getCategoryName() {
          return categoryName;
      }

      public String getCategoryDescription() {
          return categoryDescription;
      }

      public String getCategoryImageUrl() {
          return categoryImageUrl;
      }
  }